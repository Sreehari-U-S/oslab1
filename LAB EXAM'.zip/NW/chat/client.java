import java.io.*;
import java.net.*;

public class Chatclient {
private Socket socket = null;
private InputStream inStream = null;
private OutputStream outStream = null;

public Chatclient() {

}

public void createSocket() {
try {
socket = new Socket(&quot;localHost&quot;, 3339);
System.out.println(&quot;Connected&quot;);
inStream = socket.getInputStream();
outStream = socket.getOutputStream();
createReadThread();
createWriteThread();
} catch (UnknownHostException u) {

u.printStackTrace();
} catch (IOException io) {
io.printStackTrace();
}
}

public void createReadThread() {
Thread readThread = new Thread() {
public void run() {
while (socket.isConnected()) {

try {
byte[] readBuffer = new byte[200];
int num = inStream.read(readBuffer);

if (num &gt; 0) {
byte[] arrayBytes = new byte[num];
System.arraycopy(readBuffer, 0, arrayBytes, 0, num);
String recvedMessage = new String(arrayBytes, &quot;UTF-8&quot;);
System.out.println(&quot;Received message :&quot; + recvedMessage);
}
}catch (SocketException se){
System.exit(0);

} catch (IOException i) {
i.printStackTrace();
}

}
}
};

readThread.setPriority(Thread.MAX_PRIORITY);
readThread.start();
}

public void createWriteThread() {
Thread writeThread = new Thread() {
public void run() {
while (socket.isConnected()) {
try {
BufferedReader inputReader = new BufferedReader(new InputStreamReader(System.in));
sleep(100);
String typedMessage = inputReader.readLine();
if (typedMessage != null &amp;&amp; typedMessage.length() &gt; 0) {
synchronized (socket) {
outStream.write(typedMessage.getBytes(&quot;UTF-8&quot;));
sleep(100);
}
}
;

} catch (IOException i) {
i.printStackTrace();
} catch (InterruptedException ie) {
ie.printStackTrace();
}

}
}
};
writeThread.setPriority(Thread.MAX_PRIORITY);

writeThread.start();
}

public static void main(String[] args) throws Exception {
Chatclient ChatClient = new Chatclient();
ChatClient.createSocket();

}
}