#include <stdio.h>
#include<sys/types.h>
#include<unistd.h>


int main(int argc ,char *argv[]) {
  pid_t p ;
  p= fork();
  if(p==0){
      printf("Child process\n ");
      char *args[]={"abc","cdef","mno", NULL};
      execv("./hello",args);
  }
  else if(p>0){
    printf(" Parent Process\n");
    printf("pid : %d\n",getpid());
  }
  return 0;
}

