import java.io.*;
import java.net.*;
import java.util.*;
public class TCPEchoServer
{
private static ServerSocket serverSocket;
private static final int PORT = 1234;
public static void main(String[] args)
{
System.out.println(&quot;Opening port…\n&quot;);
try
{
serverSocket = new ServerSocket(PORT);
}
catch(IOException ioEx)
{
System.out.println( &quot;Unable to attach to port!&quot;);
System.exit(1);
}
do
{
handleClient();
}while (true);
}
private static void handleClient()
{
Socket link = null;
try
{

link = serverSocket.accept();
Scanner input = new Scanner(link.getInputStream());
PrintWriter output = new PrintWriter( link.getOutputStream(),true);
int numMessages = 0;
String message = input.nextLine();
while (!message.equals(&quot;CLOSE&quot;))
{
System.out.println(&quot;Message received.&quot;);
numMessages++;
output.println(&quot;Message &quot; + numMessages + &quot;: &quot; + message);
message = input.nextLine();
}
output.println(numMessages + &quot; messages received.&quot;);
}
catch(IOException ioEx)
{
ioEx.printStackTrace();
}
finally
{
try
{
System.out.println( &quot;\n Closing connection… “);
link.close();
}
catch(IOException ioEx)
{
System.out.println( &quot;Unable to disconnect!&quot;);
System.exit(1);
}
}

}
}
