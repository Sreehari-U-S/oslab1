import java.io.*;
import java.net.*;
import java.util.*;
public class TCPEchoClient
{
private static InetAddress host;
private static final int PORT = 1234;
public static void main(String[] args)
{
try
{
host = InetAddress.getLocalHost();
}
catch(UnknownHostException uhEx)
{
System.out.println(&quot;Host ID not found!&quot;);
System.exit(1);
}
accessServer();
}
private static void accessServer()
{
Socket link = null;
try
{
link = new Socket(host,PORT);
Scanner input = new Scanner(link.getInputStream());
PrintWriter output = new PrintWriter( link.getOutputStream(),true);.

Scanner userEntry = new Scanner(System.in);
String message, response;
do
{
System.out.print(&quot;Enter message: &quot;);
message = userEntry.nextLine();
output.println(message);
response = input.nextLine();
System.out.println(&quot;\nSERVER&gt; &quot;+response);
}while (!message.equals(&quot;CLOSE&quot;));
}
catch(IOException ioEx)
{
ioEx.printStackTrace();
}
finally
{
try
{
System.out.println( &quot;\nClosing connection… &quot;);
link.close();
}
catch(IOException ioEx)
{
System.out.println( &quot;Unable to disconnect!&quot;);
System.exit(1);
}
}
}
}