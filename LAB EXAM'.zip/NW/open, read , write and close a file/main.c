#include <stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdlib.h>
#include<unistd.h>

int main(void) {
  char *c = (char *)calloc(100,sizeof(char));
  int fd = open("def.txt",O_RDONLY);
  int fd2 = open("mno.txt",O_WRONLY);
  if(fd<0){
    printf("file does not exist");
    exit(1);
  }
  else{

    int s = read(fd,c,10);
    c[s]='\0';
    printf("file 1 :\n");
    printf("%s",c);
    printf("\n");
    write(fd2,c,10);
  }
  int close(int fd2);
  int close(int fd);
  return 0;
}