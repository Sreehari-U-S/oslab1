#include <stdio.h>
#include<sys/stat.h>

int main(void) {
  struct stat sfile;
  int num = stat("stat.c",&sfile);
  if(num==0){
    printf("stmode = %d\nst_uid= %d\nst_blksize = %ld\nst_gid = %d\nst_block = %ld\nst_size = %ld\n",sfile.st_mode,sfile.st_uid,sfile.st_blksize,sfile.st_gid,sfile.st_blocks,sfile.st_blksize);
  }
  else{
    printf("file does not exist");
  }
  return 0;
}